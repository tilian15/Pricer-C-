#ifndef PUTOPTION_H
#define PUTOPTION_H
#include <cmath>
#include <iostream>
#include <vector>
#include "Option.h"

class PutOption : public Option {
public:
    PutOption(double S0, double K, double r, double sigma, double T);
    double price() const override;
    double delta() const override;
    double gamma() const override;
    double vega() const override;
    double theta() const override;
    double rho() const override;
};



#endif