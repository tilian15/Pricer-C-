#ifndef AMERICAN_PUT_OPTION_H
#define AMERICAN_PUT_OPTION_H
#include <cmath>
#include <iostream>
#include <vector>
#include "AmericanOption.h"


class AmericanPutOption : public AmericanOption {
public:
    AmericanPutOption(double S0, double K, double r, double sigma, double T, int steps);
    double price() const override;
    double delta() const override;

    double gamma() const override;
    double vega() const override;
    double theta() const override;
    double rho() const override;
};

#endif