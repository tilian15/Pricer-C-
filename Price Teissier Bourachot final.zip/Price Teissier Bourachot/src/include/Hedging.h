#ifndef HEDGING_H
#define HEDGING_H

#include <cmath> // Nécessaire si vous utilisez M_PI dans Hedging.cpp
#include <vector>
#include "Option.h"


// Déclaration de la stratégie Delta Hedging
void delta_hedging(const Option* option, double initial_price, int steps, double T);

// Déclaration de la stratégie Delta-Gamma Hedging
void delta_gamma_hedging(const Option* option1, const Option* option2, double initial_price, int steps, double T);

#endif
