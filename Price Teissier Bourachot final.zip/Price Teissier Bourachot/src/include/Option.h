#ifndef OPTION_H
#define OPTION_H
#include <cmath>
#include <iostream>
#include <vector>

class Option {
protected:
    double S0;    // Prix initial de l'actif sous-jacent
    double K;     // Prix d'exercice (strike)
    double r;     // Taux d'intérêt sans risque
    double sigma; // Volatilité
    double T;     // Temps à l'échéance

public:
    Option(double S0, double K, double r, double sigma, double T);
    virtual ~Option() {}

    virtual double price() const = 0; // Méthode virtuelle pour le calcul du prix
    virtual double delta() const = 0; // Méthode virtuelle pour Delta
    virtual double gamma() const = 0; // Gamma
    virtual double vega() const = 0;  // Vega
    virtual double theta() const = 0; // Theta
    virtual double rho() const = 0;   // Rho

    double getS0() const { return S0; }
    double getK() const { return K; }
    double getR() const { return r; }
    double getSigma() const { return sigma; }
    double getT() const { return T; }

protected:
    double d1() const; // Facteur intermédiaire pour les calculs
    double d2() const; // Facteur intermédiaire pour les calculs
};


#endif