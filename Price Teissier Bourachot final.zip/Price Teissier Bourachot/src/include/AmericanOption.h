#ifndef AMERICANOPTION_H
#define AMERICANOPTION_H
#include <cmath>
#include <iostream>
#include <vector>
#include "Option.h"


class AmericanOption : public Option {
protected:
    int steps; // Nombre de pas dans l’arbre binomial

public:
    AmericanOption(double S0, double K, double r, double sigma, double T, int steps);
    virtual double price() const = 0; // Méthode virtuelle pour spécialiser Call/Put
};


#endif