#include "Hedging.h"
#include "Option.h"
#include "CallOption.h"
#include "PutOption.h"
#include "AmericanOption.h"
#include "AmericanCallOption.h"
#include "AmericanPutOption.h"
#include <iostream>

#include <memory> // Pour std::unique_ptr

#include <vector>
#include <cmath>
#include <random>

// Fonction pour générer un nombre aléatoire suivant une loi normale
double gaussian_random() {
    static std::random_device rd;
    static std::mt19937 gen(rd());
    static std::normal_distribution<> dist(0.0, 1.0);
    return dist(gen);
}

// Simulation d’un chemin pour l'actif sous-jacent
std::vector<double> simulate_path(double S0, double r, double sigma, double T, int steps) {
    double dt = T / steps;
    std::vector<double> path(steps + 1);
    path[0] = S0;

    for (int i = 1; i <= steps; ++i) {
        double Z = gaussian_random();
        path[i] = path[i - 1] * exp((r - 0.5 * sigma * sigma) * dt + sigma * sqrt(dt) * Z);
    }
    return path;
}

int main() {
    // Paramètres de l'option avec valeurs par défaut
    double S0 = 100.0, K = 100.0, r = 0.05, sigma = 0.2, T = 1.0;
    int steps = 100;

    // Demander à l'utilisateur s'il veut des valeurs par défaut ou personnalisées
    std::cout << "Souhaitez-vous utiliser les valeurs par défaut ou personnaliser les paramètres ? (d/p) : ";
    char choix;
    std::cin >> choix;

    if (choix == 'p' || choix == 'P') {
        std::cout << "Entrez le prix initial de l'actif (S0) : ";
        std::cin >> S0;
        std::cout << "Entrez le prix d'exercice (K) : ";
        std::cin >> K;
        std::cout << "Entrez le taux sans risque (r) : ";
        std::cin >> r;
        std::cout << "Entrez la volatilité (sigma) : ";
        std::cin >> sigma;
        std::cout << "Entrez le temps jusqu'à maturité (T) : ";
        std::cin >> T;
        std::cout << "Entrez le nombre de pas de simulation (steps) : ";
        std::cin >> steps;
    } else {
        std::cout << "Utilisation des valeurs par défaut." << std::endl;
    }

    // Création des options (Call et Put)
    std::unique_ptr<Option> call = std::make_unique<CallOption>(S0, K, r, sigma, T);
    std::unique_ptr<Option> put = std::make_unique<PutOption>(S0, K, r, sigma, T);

    // Stratégie Delta Hedging
    std::cout << "Testing Delta Hedging Strategy:" << std::endl;
    delta_hedging(call.get(), S0, steps, T);

    // Stratégie Delta-Gamma Hedging
    std::cout << "Testing Delta-Gamma Hedging Strategy:" << std::endl;
    delta_gamma_hedging(call.get(), put.get(), S0, steps, T);

    // À la fin du programme
    std::cout << "Appuyez sur Entrée pour quitter..." << std::endl;
    std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n'); // Vider le buffer
    std::cin.get(); // Attendre une touche
    return 0;
}
