#include <iostream>
#include <iomanip>
#include <memory> // Pour std::unique_ptr
#include "Option.h"
#include "CallOption.h"
#include "PutOption.h"
#include "AmericanOption.h"
#include "AmericanCallOption.h"
#include "AmericanPutOption.h"
#include <vector>
#include <random>
#include <cmath>

// Fonction pour générer un nombre aléatoire suivant une loi normale
double gaussian_random() {
    static std::random_device rd;
    static std::mt19937 gen(rd());
    static std::normal_distribution<> dist(0.0, 1.0);
    return dist(gen);
}

// Simulation d’un chemin pour l'actif sous-jacent
std::vector<double> simulate_path(double S0, double r, double sigma, double T, int steps) {
    double dt = T / steps;
    std::vector<double> path(steps + 1);
    path[0] = S0;
    for (int i = 1; i <= steps; ++i) {
        double Z = gaussian_random();
        path[i] = path[i - 1] * exp((r - 0.5 * sigma * sigma) * dt + sigma * sqrt(dt) * Z);
    }
    return path;
}

// Calcul du prix d’une option via Monte-Carlo
// Utilisation d'un pointeur constant "const Option* option" pour permettre le polymorphisme et permettre d'utiliser tout type d'option
double monte_carlo_pricer(const Option* option, int num_paths, int steps) {
    double payoff_sum = 0.0;
    for (int i = 0; i < num_paths; ++i) {
        auto path = simulate_path(option->getS0(), option->getR(), option->getSigma(), option->getT(), steps);
        double payoff = option->price();
        payoff_sum += payoff;
    }
    // Pourquoi un pointeur ? Le polymorphisme permet ici de passer une instance de CallOption ou PutOption
    return exp(-option->getR() * option->getT()) * (payoff_sum / num_paths);
}

// Fonction principale
int main() {
    double S0 = 100.0, K = 100.0, r = 0.05, sigma = 0.2, T = 1.0;
    int steps = 100, num_paths = 100000;

    // Demander à l'utilisateur s'il souhaite utiliser des valeurs par défaut ou personnaliser
    char choix;
    std::cout << "Voulez-vous utiliser les valeurs par défaut (d) ou entrer vos propres valeurs (p) ? (d/p) : ";
    std::cin >> choix;

    if (choix == 'p' || choix == 'P') {
        std::cout << "Entrez la valeur initiale de l'actif (S0) : ";
        std::cin >> S0;
        std::cout << "Entrez le prix d'exercice (K) : ";
        std::cin >> K;
        std::cout << "Entrez le taux d'intérêt (r) : ";
        std::cin >> r;
        std::cout << "Entrez la volatilité (sigma) : ";
        std::cin >> sigma;
        std::cout << "Entrez la maturité (T) : ";
        std::cin >> T;
        std::cout << "Entrez le nombre d'étapes dans la simulation (steps) : ";
        std::cin >> steps;
        std::cout << "Entrez le nombre de chemins pour la simulation Monte-Carlo (num_paths) : ";
        std::cin >> num_paths;
    }

    // Utilisation de pointeurs intelligents pour les options
    // 1. std::unique_ptr<Option> permet d'allouer dynamiquement des objets Option dérivés (CallOption, PutOption)
    // 2. Pourquoi des pointeurs intelligents ? 
    //    - Gestion automatique de la mémoire (pas besoin de delete)
    //    - Évite les fuites mémoire
    //    - Compatible avec le polymorphisme
    std::unique_ptr<Option> call = std::make_unique<CallOption>(S0, K, r, sigma, T);
    std::unique_ptr<Option> put = std::make_unique<PutOption>(S0, K, r, sigma, T);

    // Création des options américaines
    std::unique_ptr<Option> american_call = std::make_unique<AmericanCallOption>(S0, K, r, sigma, T, steps);
    std::unique_ptr<Option> american_put = std::make_unique<AmericanPutOption>(S0, K, r, sigma, T, steps);

    // Affichage des prix pour les options américaines
    std::cout << "Prix Call Américain : " << american_call->price() << std::endl;
    std::cout << "Prix Put Américain  : " << american_put->price() << std::endl;


    // // Appel aux méthodes via les pointeurs intelligents
    // // L'opérateur "->" est utilisé pour accéder aux méthodes des objets via les pointeurs
    std::cout << std::fixed << std::setprecision(4);
    std::cout << "Prix Call : " << call->price() << std::endl;
    std::cout << "Prix Put  : " << put->price() << std::endl;
    std::cout << "Delta Call : " << call->delta() << std::endl;
    std::cout << "Gamma Call : " << call->gamma() << std::endl;
    std::cout << "Vega Call  : " << call->vega() << std::endl;
    std::cout << "Theta Call : " << call->theta() << std::endl;
    std::cout << "Rho Call   : " << call->rho() << std::endl;

    std::cout << "Delta Put : " << put->delta() << std::endl;
    std::cout << "Gamma Put : " << put->gamma() << std::endl;
    std::cout << "Vega Put  : " << put->vega() << std::endl;
    std::cout << "Theta Put : " << put->theta() << std::endl;
    std::cout << "Rho Put   : " << put->rho() << std::endl;


    // Passage de pointeurs classiques "call.get()" à monte_carlo_pricer
    // Pourquoi call.get() ? 
    //    - call.get() retourne un pointeur brut "Option*" à partir de std::unique_ptr
    //    - Cela est nécessaire car monte_carlo_pricer attend un pointeur constant
    std::cout << "Prix Call (Monte-Carlo) : " 
              << monte_carlo_pricer(call.get(), num_paths, steps) << std::endl;

    std::cout << "Prix Put (Monte-Carlo) : " 
              << monte_carlo_pricer(put.get(), num_paths, steps) << std::endl;



    // À la fin du bloc, les pointeurs intelligents libèrent automatiquement la mémoire
    
  // À la fin du programme
    std::cout << "Appuyez sur Entrée pour quitter..." << std::endl;
    std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n'); // Vider le buffer
    std::cin.get(); // Attendre une touche
    return 0;

    
   
}
