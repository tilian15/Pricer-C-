
#include "../include/CallOption.h"
#include <cmath>
#include <algorithm>

#ifndef M_PI
#define M_PI 3.14159265358979323846
#endif



// Constructeur de CallOption
CallOption::CallOption(double S0, double K, double r, double sigma, double T)
    : Option(S0, K, r, sigma, T) {}

// Calcul du prix pour une option Call
double CallOption::price() const {
    double d1_ = d1();
    double d2_ = d2();
    return S0 * 0.5 * (1 + std::erf(d1_ / std::sqrt(2))) -
           K * exp(-r * T) * 0.5 * (1 + std::erf(d2_ / std::sqrt(2)));
}

// Calcul du Delta pour une option Call
double CallOption::delta() const {
    double d1_ = d1();
    return 0.5 * (1 + std::erf(d1_ / std::sqrt(2)));
}

double CallOption::gamma() const {
    double d1_ = d1();
    return exp(-0.5 * d1_ * d1_) / (S0 * sigma * sqrt(2 * M_PI * T));
}

double CallOption::vega() const {
    double d1_ = d1();
    return S0 * sqrt(T) * exp(-0.5 * d1_ * d1_) / sqrt(2 * M_PI);
}

double CallOption::theta() const {
    double d1_ = d1();
    double d2_ = d2();
    return - (S0 * sigma * exp(-0.5 * d1_ * d1_) / (2 * sqrt(2 * M_PI * T)))
           - r * K * exp(-r * T) * 0.5 * (1 + std::erf(d2_ / sqrt(2)));
}

double CallOption::rho() const {
    double d2_ = d2();
    return K * T * exp(-r * T) * 0.5 * (1 + std::erf(d2_ / sqrt(2)));
}


