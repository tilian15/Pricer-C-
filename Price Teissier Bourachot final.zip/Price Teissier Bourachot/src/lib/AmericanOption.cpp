
#include "../include/AmericanCallOption.h"
#include <cmath>
#include <algorithm>

#ifndef M_PI
#define M_PI 3.14159265358979323846
#endif


// Constructeur pour la classe AmericanOption
AmericanOption::AmericanOption(double S0, double K, double r, double sigma, double T, int steps)
    : Option(S0, K, r, sigma, T), steps(steps) {}


