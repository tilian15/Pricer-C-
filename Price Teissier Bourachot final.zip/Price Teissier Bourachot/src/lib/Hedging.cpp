#include "Hedging.h"
#include <iostream>
#include <cmath>
#include <vector>

// Inclure la fonction simulate_path si elle n'est pas dans une bibliothèque séparée
extern std::vector<double> simulate_path(double S0, double r, double sigma, double T, int steps);


#include <fstream> // Pour gérer les fichiers CSV


// 
// Utilisation d'un pointeur constant "const Option* option" pour permettre le polymorphisme et permettre d'utiliser tout type d'option
void delta_hedging(const Option* option, double initial_price, int steps, double T) {
    double portfolio_value = 0.0;
    double cash = 0.0;
    double stock_position = 0.0;

    // Simulation du chemin
    auto path = simulate_path(option->getS0(), option->getR(), option->getSigma(), T, steps);

    // Ouvrir un fichier CSV pour l'export
    std::ofstream file("delta_hedging.csv");
    file << "Step,Stock Price,Portfolio Value,Delta\n";

    std::cout << "Step | Stock Price | Portfolio Value | Delta\n";
    std::cout << "---------------------------------------------\n";

    for (size_t i = 0; i < path.size() - 1; ++i) {
        double current_price = path[i];
        double next_price = path[i + 1];

        // Recalculer Delta
        double delta = option->delta();

        // Ajuster la position dans le sous-jacent
        double new_stock_position = delta;
        cash += (stock_position - new_stock_position) * current_price;

        // Mettre à jour les valeurs
        stock_position = new_stock_position;
        portfolio_value = stock_position * next_price + cash;

        // Afficher les résultats dans la console
        std::cout << i << " | " << current_price << " | " << portfolio_value << " | " << delta << "\n";

        // Écrire les données dans le fichier CSV
        file << i << "," << current_price << "," << portfolio_value << "," << delta << "\n";
    }

    file.close(); // Fermer le fichier
    std::cout << "Données de Delta Hedging enregistrées dans 'delta_hedging.csv'." << std::endl;
}


// void delta_hedging(const Option* option, double initial_price, int steps, double T) {
//     double portfolio_value = 0.0;
//     double cash = 0.0;
//     double stock_position = 0.0;

//     // Simulation du chemin
//     auto path = simulate_path(option->getS0(), option->getR(), option->getSigma(), T, steps);

//     for (size_t i = 0; i < path.size() - 1; ++i) {
//         double current_price = path[i];
//         double next_price = path[i + 1];

//         // Recalculer Delta
//         double delta = option->delta();

//         // Ajuster la position dans le sous-jacent
//         double new_stock_position = delta;
//         cash += (stock_position - new_stock_position) * current_price;

//         // Mettre à jour les valeurs
//         stock_position = new_stock_position;
//         portfolio_value = stock_position * next_price + cash;

//         std::cout << "Step: " << i
//                   << ", Stock Price: " << current_price
//                   << ", Delta: " << delta
//                   << ", Portfolio Value: " << portfolio_value << std::endl;
//     }
// }

// void delta_gamma_hedging(const Option* option1, const Option* option2, double initial_price, int steps, double T) {
//     double portfolio_value = 0.0;
//     double cash = 0.0;
//     double stock_position = 0.0;
//     double gamma_position = 0.0;

//     // Simulation du chemin
//     auto path = simulate_path(option1->getS0(), option1->getR(), option1->getSigma(), T, steps);

//     for (size_t i = 0; i < path.size() - 1; ++i) {
//         double current_price = path[i];
//         double next_price = path[i + 1];

//         // Recalculer Delta et Gamma
//         double delta1 = option1->delta();
//         double delta2 = option2->delta();
//         double gamma1 = option1->gamma();
//         double gamma2 = option2->gamma();

//         // Ajuster Gamma avec une deuxième option
//         gamma_position = -gamma1 / gamma2;
//         double combined_delta = delta1 + gamma_position * delta2;

//         // Ajuster la position dans le sous-jacent
//         cash += (stock_position - combined_delta) * current_price;

//         // Mettre à jour les valeurs
//         stock_position = combined_delta;
//         portfolio_value = stock_position * next_price + cash;

//         std::cout << "Step: " << i
//                   << ", Stock Price: " << current_price
//                   << ", Combined Delta: " << combined_delta
//                   << ", Portfolio Value: " << portfolio_value << std::endl;
//     }
// }


void delta_gamma_hedging(const Option* option1, const Option* option2, double initial_price, int steps, double T) {
    double portfolio_value = 0.0;
    double cash = 0.0;
    double stock_position = 0.0;
    double gamma_position = 0.0;

    // Simulation du chemin
    auto path = simulate_path(option1->getS0(), option1->getR(), option1->getSigma(), T, steps);

    // Fichier CSV pour enregistrer les résultats
    std::ofstream file("delta_gamma_hedging.csv");
    file << "Step,Stock Price,Portfolio Value,Combined Delta,Gamma Position\n";

    std::cout << "Step | Stock Price | Portfolio Value | Combined Delta | Gamma Position\n";
    std::cout << "---------------------------------------------------------------\n";

    for (size_t i = 0; i < path.size() - 1; ++i) {
        double current_price = path[i];
        double next_price = path[i + 1];

        // Recalculer Delta et Gamma
        double delta1 = option1->delta();
        double delta2 = option2->delta();
        double gamma1 = option1->gamma();
        double gamma2 = option2->gamma();

        // Ajuster Gamma avec une deuxième option
        gamma_position = -gamma1 / gamma2;
        double combined_delta = delta1 + gamma_position * delta2;

        // Ajuster la position dans le sous-jacent
        cash += (stock_position - combined_delta) * current_price;

        // Mettre à jour les valeurs
        stock_position = combined_delta;
        portfolio_value = stock_position * next_price + cash;

        // Afficher les résultats dans la console
        std::cout << i << " | " << current_price << " | " << portfolio_value
                  << " | " << combined_delta << " | " << gamma_position << std::endl;

        // Enregistrer les résultats dans le fichier CSV
        file << i << "," << current_price << "," << portfolio_value
             << "," << combined_delta << "," << gamma_position << "\n";
    }

    file.close();
    std::cout << "Données de Delta-Gamma Hedging enregistrées dans 'delta_gamma_hedging.csv'." << std::endl;
}

