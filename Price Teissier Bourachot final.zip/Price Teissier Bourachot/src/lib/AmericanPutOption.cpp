
#include "../include/AmericanPutOption.h"
#include <cmath>
#include <algorithm>

#ifndef M_PI
#define M_PI 3.14159265358979323846
#endif



// Constructeur pour AmericanPutOption
AmericanPutOption::AmericanPutOption(double S0, double K, double r, double sigma, double T, int steps)
    : AmericanOption(S0, K, r, sigma, T, steps) {}


// Pricing d'une option américaine Put avec un arbre binomial
double AmericanPutOption::price() const {
    double dt = T / steps;
    double u = exp(sigma * sqrt(dt));
    double d = 1 / u;
    double p = (exp(r * dt) - d) / (u - d);

    // Arbre pour les prix
    std::vector<std::vector<double>> stockTree(steps + 1, std::vector<double>(steps + 1));
    for (int i = 0; i <= steps; ++i) {
        for (int j = 0; j <= i; ++j) {
            stockTree[i][j] = S0 * pow(u, j) * pow(d, i - j);
        }
    }

    // Arbre pour les payoffs
    std::vector<std::vector<double>> payoffTree(steps + 1, std::vector<double>(steps + 1));
    for (int j = 0; j <= steps; ++j) {
        payoffTree[steps][j] = std::max(K - stockTree[steps][j], 0.0);
    }

    for (int i = steps - 1; i >= 0; --i) {
        for (int j = 0; j <= i; ++j) {
            double hold = exp(-r * dt) * (p * payoffTree[i + 1][j + 1] + (1 - p) * payoffTree[i + 1][j]);
            double exercise = std::max(K - stockTree[i][j], 0.0);
            payoffTree[i][j] = std::max(hold, exercise);
        }
    }

    return payoffTree[0][0];
}

double AmericanPutOption::delta() const {
    double dt = T / steps;
    double u = exp(sigma * sqrt(dt));
    double d = 1 / u;
    double p = (exp(r * dt) - d) / (u - d);

    // Calcul de Delta à partir des deux premiers niveaux de l’arbre
    double stock_up = S0 * u;
    double stock_down = S0 * d;
    double payoff_up = std::max(K - stock_up, 0.0);
    double payoff_down = std::max(K - stock_down, 0.0);

    return (payoff_up - payoff_down) / (stock_up - stock_down);
}



// Nous sommes obligés ici de donner une valeur aux grecs (gamma, vega, theta, rho) 
// car ces méthodes sont définies comme virtuelles pures dans la classe abstraite Option (Option.h).
// En C++, une méthode virtuelle pure (virtual double gamma() const = 0;) 
// oblige les classes dérivées (comme AmericanCallOption ou AmericanPutOption) à fournir une implémentation, 
// même si celle-ci n'a pas de sens dans certains contextes (comme ici, pour les options américaines 
// où les grecs ne sont pas toujours directement calculés). 
//
// Dans ce cas, nous avons choisi de retourner des valeurs par défaut (0.0), pour respecter 
// les exigences de la classe abstraite tout en évitant d'implémenter des calculs inutiles.

double AmericanPutOption::gamma() const {
    return 0.0;
}

double AmericanPutOption::vega() const {
    return 0.0;
}

double AmericanPutOption::theta() const {
    return 0.0;}

double AmericanPutOption::rho() const {
    return 0.0;
}
