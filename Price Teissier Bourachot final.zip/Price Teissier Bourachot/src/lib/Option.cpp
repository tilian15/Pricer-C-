
#include "../include/Option.h"
#include <cmath>
#include <algorithm>

// #ifndef M_PI
// #define M_PI 3.14159265358979323846
// #endif


// Constructeur de la classe Option
Option::Option(double S0, double K, double r, double sigma, double T)
    : S0(S0), K(K), r(r), sigma(sigma), T(T) {}

// Méthodes protégées pour calculer d1 et d2
double Option::d1() const {
    return (log(S0 / K) + (r + 0.5 * sigma * sigma) * T) / (sigma * sqrt(T));
}

double Option::d2() const {
    return d1() - sigma * sqrt(T);
}
